/*
 * @author Sariah Schulteis 
 * A JUnit test class to test ComplexNum
 */
package assg5_schulteiss20;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestComplexNum {
	ComplexNum c1, c2, c3, c4, c5, c6, c7, c8;
	
	@Before
	public void setUp() throws Exception {
	
	c1 = new ComplexNum();
	c2 = new ComplexNum(2.5);
	c3 = new ComplexNum(2.5, 4.5);
	c4 = new ComplexNum(2.0, 3.0);
	c5 = new ComplexNum(1.0, 3.0);
	c6 = new ComplexNum(1.0, 3.0);
	}
	
	@Test
	public void testDefaultConstructor() {
		assertEquals("c1's real number is ", 0, c1.getReal(), 0);
		assertEquals("c2's real number is ", 2.5, c2.getReal(), 2.5);
	}
	@Test
	public void testOneParameterConstructor() {
		assertEquals("c2's real number is ", 2.5, c2.getReal(), 2.5);
		assertEquals("c3's real number is ", 2.5, c3.getReal(), 2.5);
	}
	@Test
	public void testTwoParameterConstructor() {
		assertEquals("c3's real number is  ", 2.5, c3.getReal(), 2.5);
		assertEquals("c3's imaginary number is ", 4.5, c3.getImaginary(), 4.5);
	}
	@Test
	public void testComplexAdd() {
		c7 = c3.ComplexAdd(c4);
		c8 = c4.ComplexAdd(c5);
		assertEquals("c3 + c4 is ", c7, c3.ComplexAdd(c4));
		assertEquals("c4 + c5 is ", c8, c4.ComplexAdd(c5));
	}
	@Test
	public void testComplexMul() {
		c7 = c3.ComplexMul(c4);
		c8 = c5.ComplexMul(c3);
		assertEquals("c3 * c4 is ", c7, c3.ComplexMul(c4));
		assertEquals("c5 * c3 is ", c8, c5.ComplexMul(c3));
	}
	@Test
	public void testComplexSub() {
		c7 = c2.ComplexSub(c3);
		c8 = c3.ComplexSub(c4);
		assertEquals("c2 - c3 is ", c7, c2.ComplexSub(c3));
		assertEquals("c3 - c4 is ", c8, c3.ComplexSub(c4));
	}
	@Test
	public void testComplexNeg() {
		c7 = c3.ComplexNeg();
		c8 = c4.ComplexNeg();
		assertEquals("Negation is ", c7, c3.ComplexNeg());
		assertEquals("Negation is ", c8, c4.ComplexNeg());
	}
	
	@Test
	public void testSetReal() {
		c3.setReal(1.0);
		assertEquals("c3's new real number is ", 1.0, c3.getReal(), 0.0);
		c4.setReal(2.0);
		assertEquals("c4's new real number is ", 2.0, c4.getReal(), 0.0);
	}
	@Test
	public void testSetImaginary() {
		c3.setImaginary(1.0);
		assertEquals("c3's imaginary number is ", 1.0, c3.getImaginary(), 0.0);
		c4.setImaginary(2.0);
		assertEquals("c4's imaginary number is ", 2.0, c4.getImaginary(), 0.0);
	}
	@Test
	public void testToString() {
		assertEquals("c2 toString","2.5" ,c2.toString());
		assertEquals("c3 toString", "2.5+4.5i", c3.toString());
	}
	@Test
	public void testEquals() {
		assertEquals("c1 equals c5 ", false,c1.equals(c5));
		assertEquals("c6 equals c5 ", true, c6.equals(c5));
		
	}
  }
		
