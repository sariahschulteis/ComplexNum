/* @author Sariah Schulteis
	 * A class for ComplexNum
	 */

package assg5_schulteiss20;



	
	/**
	 *Initialized variables in public class ComplexNum
	 */
	public class ComplexNum {
		double real;
		double imaginary;
	/**
	 * Default Constructor
	 */
		public ComplexNum() {
			real = 0;
			imaginary = 0;

		}
	/*
	 * Constructor with a given real number
	 * @param r is the given real number
	 */
		public ComplexNum(double r) {
			imaginary = 0;
			real = r;
		}
	/**
	 * Constructor with a given real and imaginary number
	 * @param r given real number
	 * @param i given imaginary number
	 */
		public ComplexNum(double r, double i) {
			real = r;
			imaginary = i;
		}
	/**
	 * Adds both ComlexNums together
	 * @param c is the other ComplexNum
	 * @return c1, the total of the ComplexNums
	 */
		public ComplexNum ComplexAdd(ComplexNum c) {
			// (a+bi)+(c+di) = (a+c)+(b+d)i
			ComplexNum c1 = new ComplexNum((this.real + c.real), (this.imaginary + c.imaginary));
			return c1;
		}
	/**
	 * Subtracts the ComplexNums
	 * @param c is the other ComplexNum
	 * @return c2, the total of the ComplexNums
	 */
		public ComplexNum ComplexSub(ComplexNum c) {
			// a+bi)-(c+di) = (a-c)+(b-d)i
			ComplexNum c2 = new ComplexNum((this.real - c.real), (this.imaginary - c.imaginary));
			return c2;
		}
	/*
	 * Multiplies the ComplexNums
	 * @param c is the other ComplexNum
	 * @return c3, the total of the ComplexNums
	 */
		public ComplexNum ComplexMul(ComplexNum c) {
			// a+bi)*(c+di) = (ac-bd)+(ad+bc)i
			ComplexNum c3 = new ComplexNum((this.real * c.real) - (this.imaginary * c.imaginary),
					(this.imaginary * c.imaginary) + (this.imaginary * c.imaginary));
			return c3;
		}
	/**
	 * Negates the ComplexNums
	 * @return c4, the negation of the ComplexNums
	 */
		public ComplexNum ComplexNeg() {
			// -(a+bi) = -a-bi
			ComplexNum c4 = new ComplexNum(((-1 * this.real) - this.imaginary));
			return c4;
		}
	/**
	 * Retrieves the real number
	 * @return the real number
	 */
		public double getReal() {
			return real;
		}
	/**
	 * Retrieves the imaginary number
	 * @return the imaginary number
	 */
		public double getImaginary() {
			return imaginary;
		}
	/**
	 * Modify the real number
	 * @param newReal the new real number
	 */
		public void setReal(double newReal) {
			real = newReal;
		}
	/**
	 * Modify the imaginary number
	 * @param newImaginary the new imaginary number
	 */
		public void setImaginary(double newImaginary) {
			imaginary = newImaginary;
		}
	/**
	 * Returns the string with real and imaginary numbers
	 * @return string with real or imaginary numbers based on test cases
	 */
		@Override
		public String toString() {
			if (real > 0 && imaginary > 0) {
				return real + "+" + imaginary + "i";

			} else if (real == 0) {
				return imaginary + "i";
			} else if (imaginary == 0) {
				return Double.toString(real);
			} else {
				return real + " - " + imaginary + "i";
			}
		}
	/**
	 * Compare ComplexNum with another object
	 * @param obj the object to compare
	 * @return Returns true if ComplexNum = obj. Otherwise, return false
	 */
		@Override
		public boolean equals(Object obj) {
			if (obj == null) {
				return false;
			}

			if (obj instanceof ComplexNum) {
				ComplexNum c5 = (ComplexNum) obj;
				if (this.real == c5.real && this.imaginary == c5.imaginary) {
					return true;
				}
			}
			return false;

		}
	

}
