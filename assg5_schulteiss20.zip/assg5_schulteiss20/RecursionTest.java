/*
 * @author Sariah Schulteis
 * This program uses recursion to get the substring from a user input string
 */
package assg5_schulteiss20;

import java.util.Scanner;

public class RecursionTest {

	public static void main(String[] args) {
		do {
			Scanner keyboard = new Scanner(System.in);
			System.out.println("Enter 1, 2, or 3");
			System.out.println("1. Test two-parameter substringRecursive method");
			System.out.println("2. Test three-parameter substringRecursive method");
			System.out.println("3. Exit");
			System.out.println();
			int num = keyboard.nextInt();

			if (num == 1) {
				System.out.println("Please enter a string and the beginning index");
				String string = keyboard.next();
				int initIndex = keyboard.nextInt();
				System.out.println(substringRecursive(string, initIndex));
				System.out.println();
			}

			else if (num == 2) {
				System.out.println("Please enter a string, the beginning index, and the ending index");
				String string = keyboard.next();
				int initIndex = keyboard.nextInt();
				int finalIndex = keyboard.nextInt();
				System.out.println(substringRecursive(string, initIndex, finalIndex));
				System.out.println();
			} else {
				System.exit(0);
			}
		} while (true);

	}

	/*
	 * This method uses recursion to get the substring from a user input string
	 * 
	 * @param str the given string
	 * 
	 * @param initIndex the given beginning index
	 * 
	 * @return the substring
	 */
	public static String substringRecursive(String str, int initIndex) {
		if (str.length() == initIndex) {

			return "";
		} else {
			return str.charAt(initIndex) + substringRecursive(str, initIndex + 1);
		}
	}

	/*
	 * This method uses recursion to get the substring from a user input string
	 * 
	 * @param str the given string
	 * 
	 * @param initIndex the given beginning index
	 * 
	 * @param finalIndex the given end index
	 * 
	 * @return the substring
	 */
	public static String substringRecursive(String str, int initIndex, int finalIndex) {
		if (initIndex == finalIndex) {
			return "";
		} else {
			return str.charAt(initIndex) + substringRecursive(str, initIndex + 1, finalIndex);
		}
	}
}
